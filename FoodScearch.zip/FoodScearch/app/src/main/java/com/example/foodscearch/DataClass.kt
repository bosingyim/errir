package com.example.foodscearch

data class DataClass(var dataImage:Int, var dataTitle:String)
